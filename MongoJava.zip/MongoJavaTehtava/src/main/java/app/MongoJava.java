package app;

import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;
import com.mongodb.ServerAddress;

import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Aggregates;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;

import org.bson.Document;
import org.bson.conversions.Bson;
import org.bson.json.JsonWriterSettings;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;

import com.mongodb.Block;

import com.mongodb.client.MongoCursor;
import static com.mongodb.client.model.Filters.*;
import com.mongodb.client.result.DeleteResult;
import static com.mongodb.client.model.Updates.*;
import com.mongodb.client.result.UpdateResult;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.function.Consumer;

import static java.util.Collections.singletonList;
public class MongoJava {

	//Create a connection string to the local MongoDB - local: in your own machine
	private static MongoClientURI connectionString = new MongoClientURI("mongodb://localhost:27017");
		//Create a connection client using the connection string
	private static MongoClient mongoClient = new MongoClient(connectionString);
	//Use the existing database - or create a new one, if the database does not exist
	private static MongoDatabase database = mongoClient.getDatabase("kuntavaali");
	private static MongoCollection<Document> collection = database.getCollection("candidate");
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Tervetuloa. Ohjelmassa voit lis�t� ehdokkaita kuntavaali-tietokantaan ja "
				+ "katsoa listauksen kaikista ehdokkaista sek� ehdokkaista puolueittain.");
		addCandidate();
		printAllCandidates();
		printPartyCandidates();
	}

public static void addCandidate() {
	boolean keepAdding;
	keepAdding = true;
	String number = "";
	String firstname = "";
	String lastname = "";
	String age = "";
	String party = "";
	String answer = "";
	
	Scanner in = new Scanner(System.in);
	System.out.println("Haluatko lis�t� ehdokkaita? kylla/ei");
	answer = in.nextLine();
	if (answer.contentEquals("kylla"))
		{
	
		System.out.println("Lis�t��n ehdokkaiden tietoja");
		do
		{
		//	Scanner in = new Scanner(System.in);
			System.out.println("Ehdokkaan numero");
			number = in.nextLine();
		
			System.out.println("Ehdokkaan etunimi");
			firstname = in.nextLine();
		
			System.out.println("Ehdokkaan sukunimi");
			lastname = in.nextLine();
		
			System.out.println("Ehdokkaan ik�");
			age = in.nextLine();
		
			System.out.println("Ehdokkaan puolue");
			party = in.nextLine();
	
			//Creating a new document object
			Document d=new Document();
			d.append("number", number);
			d.append("firstname", firstname);
			d.append("lastname", lastname);
			d.append("age", age); 
			d.append("party", party); 
			//Inserting the document into the selected collection
			collection.insertOne(d);
		
			System.out.println("Haluatko jatkaa ehdokkaiden lis��mist�? kylla/ei");
			answer = in.nextLine();
		
			if (answer.contentEquals("ei"))
			{
				System.out.println("Lopetetaan ehdokkaiden lis��minen");
				System.out.println("");
				keepAdding = false;
				break;
			}
		
		} while (keepAdding == true);
	}
	
	
}

public static void printAllCandidates() {
	// print all candidates
	System.out.println();
	System.out.println("Kaikki tietokantataulun 'kuntavaali' ehdokkaat:");
	MongoCollection<Document> collection = database.getCollection("candidate");
	//Reading all the documents of the selected collection - or actually getting a pointer to the first
	MongoCursor<Document> cursor = collection.find().iterator();
	try {
		//Looping through the whole list with hasNext() function
	    while (cursor.hasNext()) {
	    	//Looping through the candidates collection and printing info
	    	Document d=cursor.next();
	        System.out.println("Ehdokkaan numero: " + d.get("number")+" / Nimi: "+d.get("firstname") +
	        		" " + d.get("lastname")+" / Ik�: "+d.get("age")+" / Puolue: "+d.get("party"));
	    }
	} finally {
		//cursor should be closed - this finally part is good for that
	    cursor.close();
	}		
	
}

public static void printPartyCandidates() {
	// print candidates from a specific party - Tulostaa halutun puolueen ehdokkaat
	MongoCollection<Document> collection = database.getCollection("candidate");
	//Reading all the documents of the selected collection - or actually getting a pointer to the first
	MongoCursor<Document> cursor = collection.find().iterator();
	ArrayList<String> parties = new ArrayList<String>();
	String currentParty = "";
	String currentCandidate = "";
	HashMap<String, ArrayList<String>> partiesDict = new HashMap<String,ArrayList<String>>();
	String chosenParty = "";
	boolean keepPrinting = true;
	
	try {
		//Looping through the whole list with hasNext() function
	//	boolean partyInArray= parties.contains("currentParty");
	    while (cursor.hasNext()) {
	    	//Looping through the candidates collection and adding different parties to a Hashmap
	    	//where the party is a String type key and candidates are added in an ArrayList<String>
	    	Document d=cursor.next();
	        currentParty = (d.get("party")).toString();
	        currentCandidate = (d.get("number")).toString()+" "+(d.get("firstname")).toString()+" "+(d.get("lastname")).toString();
	        
	        if (partiesDict.containsKey(currentParty) == false)
	        {
	        	partiesDict.put(currentParty, new ArrayList<String>());
	        }
	        
	        partiesDict.get(currentParty).add(currentCandidate);
	       }
	    
	} finally {
		//cursor should be closed - this finally part is good for that
	    cursor.close();
	}	
	
	while (keepPrinting) {
		System.out.println("\n Valitse puolue, jonka ehdokkaat haluat tulostaa: \n");
          
		System.out.println(partiesDict.keySet()); 	
	
		Scanner in = new Scanner(System.in);
		chosenParty = in.nextLine();      
		System.out.println("Puolueen " + chosenParty + " ehdokkaat ovat: " + partiesDict.get(chosenParty));
		
		System.out.println("\n Haluatko tulostaa toisen puolueen ehdokkaat? kylla/ei \n");
		String answer = in.nextLine();
		if (answer.contentEquals("ei"))
		{
			System.out.println("Lopetetaan tietojen katselu");
			keepPrinting = false;
		}
	}
	
}

}
